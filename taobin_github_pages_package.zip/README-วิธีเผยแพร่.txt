# TAO BIN — Discover Your Dimension

เว็บไซต์แบบทดสอบจากไฟล์ต้นฉบับที่ได้รับ โดยคงคำถาม 4 ข้อและผลลัพธ์ 4 มิติไว้

## วิธีเผยแพร่ด้วย GitHub Pages (ฟรี)

1. เข้าสู่ https://github.com และลงชื่อเข้าใช้
2. กด **New repository**
3. ตั้งชื่อ repository เช่น `taobin-dimension`
4. เลือก **Public** (GitHub Free ใช้ Pages กับ public repository ได้)
5. กด **Create repository**
6. ในหน้า repository เลือก **Add file → Upload files**
7. อัปโหลด `index.html` และ `.nojekyll` จากโฟลเดอร์นี้ แล้วกด **Commit changes**
8. ไปที่ **Settings → Pages**
9. ใน **Build and deployment** เลือก **Deploy from a branch**
10. เลือก Branch `main` และ Folder `/(root)` แล้วกด **Save**
11. รอระบบเผยแพร่ จากนั้นกด **Visit site** ในหน้า Pages

URL จะมีรูปแบบ:
`https://YOUR-USERNAME.github.io/taobin-dimension/`

แทน `YOUR-USERNAME` ด้วยชื่อผู้ใช้ GitHub ของคุณ และถ้าใช้ชื่อ repository อื่น ให้เปลี่ยนส่วนท้ายตามชื่อจริง

## สร้าง QR Code

หลังจากเปิด URL เว็บไซต์จริงและทดสอบบนมือถือแล้ว:
1. คัดลอก URL ที่ใช้งานได้จริงจากหน้า GitHub Pages
2. นำ URL ไปสร้าง QR Code แบบ Static ที่บริการสร้าง QR Code ที่เชื่อถือได้
3. ดาวน์โหลดเป็น PNG ความละเอียดสูงหรือ SVG สำหรับนำไปวางบนโปสเตอร์
4. ทดสอบสแกนด้วยโทรศัพท์อย่างน้อย 2 เครื่องก่อนพิมพ์

**สำคัญ:** QR Code แบบ Static จะไม่เปลี่ยนปลายทางเอง แต่เว็บไซต์จะอยู่ได้ตราบใดที่ repository และ GitHub Pages ยังเปิดใช้งานอยู่ และ URL เดิมไม่ถูกเปลี่ยน/ลบ ไม่มีบริการออนไลน์ใดรับประกันว่าอยู่ได้ตลอดไป 100%

## การอัปเดตเกมภายหลัง

อัปโหลดไฟล์ `index.html` เวอร์ชันใหม่ทับไฟล์เดิมใน repository แล้วกด Commit changes โดยคงชื่อ repository และ URL เดิมไว้ QR Code เดิมก็จะยังชี้ไปยังหน้าเดิม
